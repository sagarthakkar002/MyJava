package com.mindtree.sringmvc.dao;

import java.util.List;

import com.mindtree.sringmvc.entity.Employee;


public interface EmployeeDao {
     public String addEmployee(Employee e);
	public Employee getEmployee(int no);
	
	public List<Employee> getAllEmployee();
	public void UpdateEmployee(Employee e);
}
