package com.mindtree.sringmvc.service.serviceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mindtree.sringmvc.dao.EmployeeDao;
import com.mindtree.sringmvc.entity.Employee;
import com.mindtree.sringmvc.service.EmployeeService;

@Component
@Repository
public class EmployeeServiceImpl implements EmployeeService {

	// EmployeeDaoImpl edao=new EmployeeDao;
	@Autowired
	private EmployeeDao edao;

	@Transactional
	public String addEmployee(Employee e) {
		// TODO Auto-generated method stub
		// edao.addEmployee(e);
		String st = edao.addEmployee(e);
		return st;

	}

	public Employee getEmployee(int no) {
		return edao.getEmployee(no);
		
	}

	public List<Employee> getAllEmployee() {
		return edao.getAllEmployee();
	}
    @Transactional
	public void UpdateEmployee(Employee e) {
		edao.UpdateEmployee(e);
		
	}

}
