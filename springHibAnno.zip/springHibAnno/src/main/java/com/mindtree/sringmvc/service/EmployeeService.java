package com.mindtree.sringmvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.sringmvc.entity.Employee;
@Service
public interface EmployeeService {
	public String addEmployee(Employee e);

	public Employee getEmployee(int no);
	
	List<Employee> getAllEmployee();
	public void UpdateEmployee(Employee e);
}
