package com.mindtree.sringmvc.springHibAnno;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindtree.sringmvc.configuration.hiberconfing;
import com.mindtree.sringmvc.entity.Employee;
import com.mindtree.sringmvc.service.EmployeeService;
import com.mindtree.sringmvc.service.serviceImpl.EmployeeServiceImpl;

/**
 * Hello world!
 *
 */

public class App 
{
    public static void main( String[] args )
    {
    	 System.out.println( "Hi" );
    	ApplicationContext context=new AnnotationConfigApplicationContext(hiberconfing.class);
    	EmployeeService es=context.getBean(EmployeeService.class);
    	Employee e=context.getBean(Employee.class);
    /*	e.setEmpId(102);
    	e.setName("kunal");
    	e.setEmail("kunal@kunal");
    	e.setSalary(30000);
    	String st=es.addEmployee(e);
        System.out.println(st);*/
        
        Employee emp=es.getEmployee(1);
        System.out.println(emp.getName()+"\t"+emp.getEmpId()+"\t"+emp.getSalary());
        
        List<Employee> emplist=es.getAllEmployee();
        for(Employee em:emplist) {
        	System.out.println(em.getName()+"\t"+em.getEmail()+"\t"+em.getEmpId());
        }
        
        e.setEmpId(1);
        es.UpdateEmployee(e);
        
       
    }
}
