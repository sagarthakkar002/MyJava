package com.mindtree.sringmvc.dao.daoImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.mindtree.sringmvc.dao.EmployeeDao;
import com.mindtree.sringmvc.entity.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	private HibernateTemplate hibernatetemplate;

	public String addEmployee(Employee e) {
		System.out.println("entered");
	    hibernatetemplate.save(e);
		System.out.println("exit");
		return "inserted";
	}

	public Employee getEmployee(int no) {
        /* String query="select * from employee where empId="+no;*/
        Employee e= hibernatetemplate.get(Employee.class, no);
		return e;
        
         
	}

	public List<Employee> getAllEmployee() {
		List<Employee> empl=hibernatetemplate.loadAll(Employee.class);
		return empl;
	}

	

	public void UpdateEmployee(Employee e) {
		Employee enew=getEmployee(e.getEmpId());
		enew.setEmail("ashish@ashish");
		hibernatetemplate.update(enew);
		
	}
	
	

}
