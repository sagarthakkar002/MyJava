package com.mindtree.winemart.querybuilding;

import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;

public class MyQueryBuilder {
	// length of filter = 6
	public static QueryBuilder myQuery(String... filters) {
		QueryBuilder qbSearchTerm, qbWinery, qbWineType1, qbWineType2, qbFlavour, qbRegion;
		
		// if for search term
		if (filters[0] != null && filters[0] != "") {
			// search term is present
			// call multimatch query
			qbSearchTerm = QueryBuilders.matchQuery("_all", filters[0]);
			// if for winery
			if (filters[1] != null && filters[1] != "") {
				// winery is present
				// create match query for winery
				qbWinery = QueryBuilders.matchQuery("P_Winery.keyword", filters[1]);
				// if for winetype1
				if (filters[2] != null && filters[2] != "") {
					// winetype1 is present
					// create match query for winetype1
					qbWineType1 = QueryBuilders.matchQuery("P_WineType1.keyword", filters[2]);

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							System.out.println("Flavour");
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 6
								return createBoolQueryFor6(qbSearchTerm, qbWinery, qbWineType1, qbWineType2, qbFlavour,
										qbRegion);

							} else {
								// region is not present

								// call bool query for 5
								return createBoolQueryFor5(qbSearchTerm, qbWinery, qbWineType1, qbWineType2, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								System.out.println("Flavour Not present");
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 5
								return createBoolQueryFor5(qbSearchTerm, qbWinery, qbWineType1, qbWineType2, qbRegion);

							} else {
								// region is not present

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWinery, qbWineType1, qbWineType2);
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 5
								return createBoolQueryFor5(qbSearchTerm, qbWinery, qbWineType1, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWinery, qbWineType1, qbFlavour);
							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWinery, qbWineType1, qbRegion);

							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWinery, qbWineType1);
							}
						}

					}
				} else {
					// winetype1 is not present

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 5
								return createBoolQueryFor5(qbSearchTerm, qbWinery, qbWineType2, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWinery, qbWineType2, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 4

								return createBoolQueryFor4(qbSearchTerm, qbWinery, qbWineType2, qbRegion);
							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWinery, qbWineType2);
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWinery, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWinery, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWinery, qbRegion);

							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbSearchTerm, qbWinery);
							}
						}

					}
				}

			} else {
				// winery is not present

				// if for winetype1
				if (filters[2] != null && filters[2] != "") {
					// winetype1 is present
					// create match query for winetype1
					qbWineType1 = QueryBuilders.matchQuery("P_WineType1.keyword", filters[2]);

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 5
								return createBoolQueryFor5(qbSearchTerm, qbWineType1, qbWineType2, qbFlavour, qbRegion);
							} else {
								// region is not present

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWineType1, qbWineType2, qbFlavour);
							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWineType1, qbWineType2, qbRegion);

							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWineType1, qbWineType2);
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWineType1, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 3

								return createBoolQueryFor3(qbSearchTerm, qbWineType1, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWineType1, qbRegion);
							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbSearchTerm, qbWineType1);
							}
						}

					}
				} else {
					// winetype1 is not present

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbSearchTerm, qbWineType2, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWineType2, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbWineType2, qbRegion);
							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbSearchTerm, qbWineType2);
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region>keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbSearchTerm, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 2

								return createBoolQueryFor2(qbSearchTerm, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 2
								return createBoolQueryFor2(qbSearchTerm, qbRegion);
							} else {
								// region is not present

								// call query for 1
								return qbSearchTerm;
							}
						}

					}
				}

			}

		} else {
			// search term is not present

			// if for winery
			if (filters[1] != null && filters[1] != "") {
				// winery is present
				// create match query for winery
				qbWinery = QueryBuilders.matchQuery("P_Winery.keyword", filters[1]);
				// if for winetype1
				if (filters[2] != null && filters[2] != "") {
					// winetype1 is present
					// create match query for winetype1
					qbWineType1 = QueryBuilders.matchQuery("P_WineType1.keyword", filters[2]);

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 5
								return createBoolQueryFor5(qbWinery, qbWineType1, qbWineType2, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 4
								return createBoolQueryFor4(qbWinery, qbWineType1, qbWineType2, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbWinery, qbWineType1, qbWineType2, qbRegion);

							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbWinery, qbWineType1, qbWineType2);
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbWinery, qbWineType1, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbWinery, qbWineType1, qbFlavour);
							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbWinery, qbWineType1, qbRegion);

							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbWinery, qbWineType1);
							}
						}

					}
				} else {
					// winetype1 is not present

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbWinery, qbWineType2, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbWinery, qbWineType2, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3

								return createBoolQueryFor3(qbWinery, qbWineType2, qbRegion);
							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbWinery, qbWineType2);
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbWinery, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbWinery, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 2
								return createBoolQueryFor2(qbWinery, qbRegion);

							} else {
								// region is not present

								// call query for 1
								return qbWinery;
							}
						}

					}
				}

			} else {
				// winery is not present

				// if for winetype1
				if (filters[2] != null && filters[2] != "") {
					// winetype1 is present
					// create match query for winetype1
					qbWineType1 = QueryBuilders.matchQuery("P_WineType1.keyword", filters[2]);

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery(".keyword", filters[5]);

								// call bool query for 4
								return createBoolQueryFor4(qbWineType1, qbWineType2, qbFlavour, qbRegion);
							} else {
								// region is not present

								// call bool query for 3
								return createBoolQueryFor3(qbWineType1, qbWineType2, qbFlavour);
							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbWineType1, qbWineType2, qbRegion);

							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbWineType1, qbWineType2);
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbWineType1, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 2

								return createBoolQueryFor2(qbWineType1, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 2
								return createBoolQueryFor2(qbWineType1, qbRegion);
							} else {
								// region is not present

								// call query for 1
								return qbWineType1;
							}
						}

					}
				} else {
					// winetype1 is not present

					// if for winetype2
					if (filters[3] != null && filters[3] != "") {
						// winetype2 is present
						// create match query for winetype2
						qbWineType2 = QueryBuilders.matchQuery("P_WineType2.keyword", filters[3]);

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 3
								return createBoolQueryFor3(qbWineType2, qbFlavour, qbRegion);

							} else {
								// region is not present

								// call bool query for 2
								return createBoolQueryFor2(qbWineType2, qbFlavour);

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 2
								return createBoolQueryFor2(qbWineType2, qbRegion);
							} else {
								// region is not present

								// call query for 1
								return qbWineType2;
							}
						}

					} else {
						// winetype2 is not present

						// if for flavours
						if (filters[4] != null && filters[4] != "") {
							// flavours is present
							// create match query for flavours
							qbFlavour = QueryBuilders.matchQuery("P_Flavors.keyword", filters[4]);
							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call bool query for 2
								return createBoolQueryFor2(qbFlavour, qbRegion);

							} else {
								// region is not present

								// call query for 1

								return qbFlavour;

							}
						} else {
							// flavours is not present

							// if for region
							if (filters[5] != null && filters[5] != "") {
								// region is present
								// create match query for region
								qbRegion = QueryBuilders.matchQuery("P_Region.keyword", filters[5]);

								// call query for 1
								return qbRegion;
							} else {
								// region is not present

								// call default load query
								return QueryBuilders.matchAllQuery();
							}
						}

					}
				}

			}
		}

	}

	// 7-8
	public static SortBuilder<?> mySortBuilder(String sortby, String order) {
		SortBuilder<?> sortMe = null;
		if (sortby != null && sortby != ""&&order != null && order != "") {
			// write query for sort by and order by
			if (order.equals("desc")) {
				sortMe = SortBuilders.fieldSort(sortby).order(SortOrder.DESC);
			} else {
				sortMe = SortBuilders.fieldSort(sortby).order(SortOrder.ASC);
			}

		} else if (sortby != null && sortby != "") {
			// sort by default is desc
			// write query for sort by with desc order
			sortMe = SortBuilders.fieldSort(sortby).order(SortOrder.DESC);
		} else {
			sortMe = SortBuilders.fieldSort("P_WineID.keyword").order(SortOrder.ASC);;
		}

		// null is return so check in the dao before firing the query
		return sortMe;
	}

	// bool queries
	// bool query for 2 filtering
	public static QueryBuilder createBoolQueryFor2(QueryBuilder query1, QueryBuilder query2) {
		return QueryBuilders.boolQuery().must(query1).must(query2);
	}

	// bool query for 3 filtering
	public static QueryBuilder createBoolQueryFor3(QueryBuilder query1, QueryBuilder query2, QueryBuilder query3) {
		return QueryBuilders.boolQuery().must(query1).must(query2).must(query3);
	}

	// bool query for 4 filtering
	public static QueryBuilder createBoolQueryFor4(QueryBuilder query1, QueryBuilder query2, QueryBuilder query3,
			QueryBuilder query4) {
		return QueryBuilders.boolQuery().must(query1).must(query2).must(query3).must(query4);
	}

	// bool query for 5 filtering
	public static QueryBuilder createBoolQueryFor5(QueryBuilder query1, QueryBuilder query2, QueryBuilder query3,
			QueryBuilder query4, QueryBuilder query5) {
		return QueryBuilders.boolQuery().must(query1).must(query2).must(query3).must(query4).must(query5);
	}

	// bool query for 6 filtering
	public static QueryBuilder createBoolQueryFor6(QueryBuilder query1, QueryBuilder query2, QueryBuilder query3,
			QueryBuilder query4, QueryBuilder query5, QueryBuilder query6) {
		return QueryBuilders.boolQuery().must(query1).must(query2).must(query3).must(query4).must(query5).must(query6);
	}
}
