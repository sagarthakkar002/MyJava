package com.mindtree.winemart.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.sort.SortBuilder;

import com.mindtree.winemart.entity.WineDetails;
import com.mindtree.winemart.querybuilding.MyQueryBuilder;
import com.mindtree.winemart.utils.ElasticTransportConnection;

public class WineDataTransaction {
	// 9 parameters will come
	public List<Map<String, List<Object>>> requestedData(String[] requestedData) {
		TransportClient tc = ElasticTransportConnection.getConnection();
		
		AggregationBuilder wineryAggregation = AggregationBuilders.terms("wineAggs").field("P_Winery.keyword").size(5);
		
		AggregationBuilder wineType1Aggregation = AggregationBuilders.terms("wineType1Aggs")
				.field("P_WineType1.keyword").size(5);
		
		AggregationBuilder wineType2Aggregation = AggregationBuilders.terms("wineType2Aggs")
				.field("P_WineType2.keyword").size(5);
		System.out.println(wineType2Aggregation.toString());
		AggregationBuilder flavourAggregation =AggregationBuilders.terms("flavourAggs")
				.field("P_Flavors.keyword").size(5);
		AggregationBuilder regionAggregation = AggregationBuilders.terms("regionAggs").field("P_Region.keyword").size(5);
		
		List<Map<String, List<Object>>> result = null;
		List<Object> wineDetails = null;
		List<Object>totalHits=null;
		List<Object>numFoundCount=null;
		Map<String, List<Object>> winery = null;
		Map<String, List<Object>> wineType1 = null;
		Map<String, List<Object>> wineType2 = null;
		Map<String, List<Object>> flavour = null;
		Map<String, List<Object>> region = null;
		SearchResponse searchResponse = null;

		String[] queryParam = new String[6];
		for (int i = 0; i < 6; i++) {
			queryParam[i] = requestedData[i];
		}
		QueryBuilder toFireQuery = MyQueryBuilder.myQuery(queryParam);
		System.out.println(toFireQuery.toString());
		SortBuilder<?> toFireSort =  MyQueryBuilder.mySortBuilder(requestedData[6], requestedData[7]);

		/*if (requestedData[8].isEmpty()) {
			System.out.println("hello================"+requestedData[8]);
				searchResponse = tc.prepareSearch("wine_detail").setTypes("wine").addAggregation(wineryAggregation)
						.addAggregation(wineType1Aggregation).addAggregation(wineType2Aggregation)
						.addAggregation(regionAggregation).addAggregation(flavourAggregation).setQuery(toFireQuery)
						.addSort(toFireSort).setFrom(0).setSize(10).setExplain(false).execute().actionGet();

		} else {*/
			int fromRecord = Integer.parseInt(requestedData[8]);
			fromRecord=(fromRecord-1)*10;
			System.out.println("heyyyyyyyyyyyyyyy---------------------"+requestedData[8]);
		

				searchResponse = tc.prepareSearch("wine_detail").setTypes("wine").addAggregation(wineryAggregation)
						.addAggregation(wineType1Aggregation).addAggregation(wineType2Aggregation)
						.addAggregation(regionAggregation).addAggregation(flavourAggregation).setQuery(toFireQuery)
						.addSort(toFireSort).setFrom(fromRecord).setSize(10).setExplain(false).execute().actionGet();
			
		//}

		winery = getWineryMap(searchResponse);
		wineType1 = getWineType1Map(searchResponse);
		wineType2 = getWineType2Map(searchResponse);
		flavour = getFlavourMap(searchResponse);
		region = getRegionMap(searchResponse);
		wineDetails= getWineDetailsList(searchResponse);
		totalHits= new ArrayList<>();
		numFoundCount= new ArrayList<>();
		totalHits.add(searchResponse.getHits().getTotalHits());
		Map<String, List<Object>> wineDetailsMap = new HashMap<>();
		Map<String, List<Object>> totalHitsMap = new HashMap<>();
		Map<String, List<Object>> numFound = new HashMap<>();
		wineDetailsMap.put("wineDetails", (List<Object>) wineDetails);
		totalHitsMap.put("totalHits", totalHits);
		Integer size=wineDetails.size();
		System.out.println("yede size"+size);
		numFoundCount.add(size);
		numFound.put("numFound", numFoundCount);
		result = new ArrayList<Map<String, List<Object>>>();

		result.add(wineDetailsMap);
		result.add(winery);
		result.add(wineType1);
		result.add(wineType2);
		result.add(flavour);
		result.add(region);
		result.add(totalHitsMap);
		result.add(numFound);
		return result;
	}

	private List<Object> getWineDetailsList(SearchResponse searchresponse) {
		List<Object> wineDetailsList = new ArrayList<>();
		for (SearchHit hit : searchresponse.getHits()) {
			WineDetails wineDetails = new WineDetails();
			Map<String, Object> mapWineDetails = hit.getSource();
			// System.out.println(mapAccount.toString());
			wineDetails.setP_WineID(mapWineDetails.get("P_WineID").toString());
			
			if(mapWineDetails.get("P_Winery")==null) {
				wineDetails.setP_Winery("N/A");
			}else {
				wineDetails.setP_Winery(mapWineDetails.get("P_Winery").toString());
			}
			if(mapWineDetails.get("P_Wine")==null) {
				wineDetails.setP_Wine("N/A");
			}else {
				wineDetails.setP_Wine(mapWineDetails.get("P_Wine").toString());
			}
			
			if(mapWineDetails.get("P_Year")==null) {
				wineDetails.setP_Year("N/A");
			}else {
				wineDetails.setP_Year(mapWineDetails.get("P_Year").toString());
			}
			
			if(mapWineDetails.get("P_Description")==null) {
				wineDetails.setP_Description("N/A");
			}else {
				wineDetails.setP_Description(mapWineDetails.get("P_Description").toString());
			}
			
			if(mapWineDetails.get("P_PriceStr")==null) {
				wineDetails.setP_PriceStr("N/A");
			}else {
				wineDetails.setP_PriceStr(mapWineDetails.get("P_PriceStr").toString());
			}
			if(mapWineDetails.get("P_PriceStr")==null) {
				wineDetails.setP_Score("N/A");
			}else {
				wineDetails.setP_Score(mapWineDetails.get("P_Score").toString());
			}
			
			//System.out.println(wineDetails.toString());
			wineDetailsList.add(wineDetails);
		}
		return wineDetailsList;
	}

	private Map<String, List<Object>> getWineryMap(SearchResponse searchresponse) {
		Terms wineAggr = searchresponse.getAggregations().get("wineAggs");
		Map<String, List<Object>> wineryMap = new HashMap<>();
		ArrayList<Object> countWinery = null;
		for (Terms.Bucket entry : wineAggr.getBuckets()) {
			countWinery = new ArrayList<>();
			countWinery.add(entry.getDocCount());
			wineryMap.put(entry.getKey().toString(), countWinery);
			// System.out.println(entry.getKey().toString() + "" + entry.getDocCount());
		}
		return wineryMap;
	}

	private Map<String, List<Object>> getWineType1Map(SearchResponse searchresponse) {
		Terms wineType1Aggr = searchresponse.getAggregations().get("wineType1Aggs");
		Map<String, List<Object>> wineType1Map = new HashMap<>();
		ArrayList<Object> countWineType1 = null;
		for (Terms.Bucket entry : wineType1Aggr.getBuckets()) {
			countWineType1 = new ArrayList<>();
			countWineType1.add(entry.getDocCount());
			wineType1Map.put(entry.getKey().toString(), countWineType1);
			// System.out.println(entry.getKey().toString() + "" + entry.getDocCount());
		}
		return wineType1Map;
	}

	private Map<String, List<Object>> getWineType2Map(SearchResponse searchresponse) {
		Terms wineType2Aggr = searchresponse.getAggregations().get("wineType2Aggs");
		Map<String, List<Object>> wineType2Map = new HashMap<>();
		ArrayList<Object> countWineType2 = null;
		for (Terms.Bucket entry : wineType2Aggr.getBuckets()) {
			countWineType2 = new ArrayList<>();
			countWineType2.add(entry.getDocCount());
			wineType2Map.put(entry.getKey().toString(), countWineType2);
			// System.out.println(entry.getKey().toString() + "" + entry.getDocCount());
		}
		return wineType2Map;
	}

	private Map<String, List<Object>> getFlavourMap(SearchResponse searchresponse) {
		Terms flavourAggr = searchresponse.getAggregations().get("flavourAggs");
		Map<String, List<Object>> flavourMap = new HashMap<>();
		ArrayList<Object> countFlavour = null;
		for (Terms.Bucket entry : flavourAggr.getBuckets()) {
			countFlavour = new ArrayList<>();
			countFlavour.add(entry.getDocCount());
			flavourMap.put(entry.getKey().toString(), countFlavour);
			 //System.out.println(entry.getKey().toString() + "" + entry.getDocCount());
		}
		return flavourMap;
	}

	private Map<String, List<Object>> getRegionMap(SearchResponse searchresponse) {
		Terms regionAggr = searchresponse.getAggregations().get("regionAggs");
		Map<String, List<Object>> regionMap = new HashMap<>();
		ArrayList<Object> countRegion = null;
		for (Terms.Bucket entry : regionAggr.getBuckets()) {
			countRegion = new ArrayList<>();
			countRegion.add(entry.getDocCount());
			regionMap.put(entry.getKey().toString(), countRegion);
			// System.out.println(entry.getKey().toString() + "" + entry.getDocCount());
		}
		return regionMap;
	}
}

// if last parameter is empty then it will be from 0 else page from will be the query
// sort vala method 3 parameter
// query vala method with 6 parameter method