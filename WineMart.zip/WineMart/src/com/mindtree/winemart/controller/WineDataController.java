package com.mindtree.winemart.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mindtree.winemart.dao.WineDataTransaction;

@WebServlet("/WineDataController")
public class WineDataController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public WineDataController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		WineDataTransaction wdt= new WineDataTransaction();
		
		String searchTerm=request.getParameter("searchTerm");
		System.out.println("st"+searchTerm);
		String winery=request.getParameter("winery");
		System.out.println("w"+winery);
		String wineType1= request.getParameter("wineType1");
		System.out.println("wt1"+wineType1);
		String wineType2=request.getParameter("wineType2");
		System.out.println("wt2"+wineType2);
		String flavours= request.getParameter("flavours");
		System.out.println("f"+flavours);
		String region=request.getParameter("region");
		System.out.println("r"+region);
		
		String pageNum= request.getParameter("pageNum");
		
		String sortBy= request.getParameter("sortBy");
		String order=request.getParameter("order");
		String []requestParam= new String[9];
		requestParam[0]=searchTerm;
		requestParam[1]=winery;
		requestParam[2]=wineType1;
		requestParam[3]=wineType2;
		requestParam[4]=flavours;
		requestParam[5]=region;
		requestParam[6]=sortBy;
		requestParam[7]=order;
		requestParam[8]=pageNum;
		List<Map<String,List<Object>>>results=wdt.requestedData(requestParam);
		
		Set<Entry<String,List<Object>>> wineDeatilsMap= results.get(0).entrySet();
		
		//System.out.println("winery details");
		Set<Entry<String,List<Object>>>wm= results.get(1).entrySet();
		Map<String,Object>wineryMap=new HashMap<>();
		for(Entry<String,List<Object> >wmap:wm) {
			//System.out.println(wmap.getKey()+"  "+wmap.getValue().get(0));
			wineryMap.put(wmap.getKey(), wmap.getValue().get(0));
		}
		
		//System.out.println("wine type1 details");
		Set<Entry<String,List<Object>>>wt1m=results.get(2).entrySet();
		Map<String,Object>wineType1Map=new HashMap<>();
		for(Entry<String,List<Object> >wmap:wt1m) {
			//System.out.println(wmap.getKey()+"  "+wmap.getValue().get(0));
			wineType1Map.put(wmap.getKey(), wmap.getValue().get(0));
		}
		
		
		//System.out.println("wine type2 details");
		Set<Entry<String,List<Object>>>wt2m=results.get(3).entrySet();
		Map<String,Object>wineType2Map=new HashMap<>();
		for(Entry<String,List<Object> >wmap:wt2m) {
			//System.out.println(wmap.getKey()+"  "+wmap.getValue().get(0));
			wineType2Map.put(wmap.getKey(), wmap.getValue().get(0));
		}
		
		//System.out.println("flavour details");
		Set<Entry<String,List<Object>>>fm=results.get(4).entrySet();
		Map<String,Object>flavourMap=new HashMap<>();
		for(Entry<String,List<Object> >wmap:fm) {
			//System.out.println(wmap.getKey()+"  "+wmap.getValue().get(0));
			flavourMap.put(wmap.getKey(), wmap.getValue().get(0));
		}
		
		//System.out.println("region details");
		Set<Entry<String,List<Object>>>rm=results.get(5).entrySet();
		Map<String,Object>regionMap=new HashMap<>();
		for(Entry<String,List<Object> >wmap:rm) {
			//System.out.println(wmap.getKey()+"  "+wmap.getValue().get(0));
			regionMap.put(wmap.getKey(), wmap.getValue().get(0));
		}
		
		
		List<Object> wineDetailsList=null;
		Long totalHits=null;
		Integer numFound=null;
		for(Entry<String,List<Object>>wdp:wineDeatilsMap) {
			if(wdp.getKey().equals("wineDetails")) {
				wineDetailsList=wdp.getValue();
			}
		}
		Set<Entry<String,List<Object>>>totalHitsMap= results.get(6).entrySet();
		
		for(Entry<String,List<Object>>th:totalHitsMap) {

			if(th.getKey().equals("totalHits")) {
				totalHits=(Long) th.getValue().get(0);
			}
		}
		Set<Entry<String,List<Object>>>numData= results.get(7).entrySet();
		for(Entry<String,List<Object>>nd:numData) {

			if(nd.getKey().equals("numFound")) {
				
				numFound=(Integer) nd.getValue().get(0);
			}
		}
		System.out.println("=============="+numFound);
		if(wineDetailsList.size()>0) {
			if(wineDetailsList.size()==10) {
				request.setAttribute("pageNum", (Integer.parseInt(pageNum)+1));
			}else {
				request.setAttribute("disableNext", true);
			}
			request.setAttribute("wineDetailsList", wineDetailsList);
			request.setAttribute("totalHits", totalHits);
			request.setAttribute("wineryMap", wineryMap);
			request.setAttribute("wineType1Map", wineType1Map);
			request.setAttribute("wineType2Map", wineType2Map);
			request.setAttribute("flavourMap", flavourMap);
			request.setAttribute("regionMap", regionMap);
			
			request.setAttribute("searchTerm", searchTerm);
			request.setAttribute("winery", winery);
			request.setAttribute("wineType1", wineType1);
			request.setAttribute("wineType2", wineType2);
			request.setAttribute("flavours", flavours);
			request.setAttribute("region", region);
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("sortBy", sortBy);
			request.setAttribute("order", order);
			
			request.setAttribute("numFound", numFound);
			request.setAttribute("totalHits", totalHits);
			request.getRequestDispatcher("/main.jsp").forward(request, response);
			
		}else {
			request.getRequestDispatcher("/noresults.jsp").forward(request, response);
		}
		
		//getpagenum
		//get size of document list for pagination
		//get totalhits
		//get winery
		//get wine type1
		//get wine type2
		//get flavour
		//get region
		//getwinedetails
		
	}

}
