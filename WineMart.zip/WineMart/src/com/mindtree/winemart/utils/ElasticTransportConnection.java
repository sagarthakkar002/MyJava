package com.mindtree.winemart.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

public class ElasticTransportConnection {
	public static TransportClient tc=null;
	
	public static TransportClient getConnection() {
		
		Settings settings= Settings.builder().put("cluster.name","my-application").build();
		try {
			if(tc==null)
				tc= new PreBuiltTransportClient(settings).addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("127.0.0.1"),9300));
		} catch (UnknownHostException e) {
				e.printStackTrace();
			}
		return tc;
		
	}
}
