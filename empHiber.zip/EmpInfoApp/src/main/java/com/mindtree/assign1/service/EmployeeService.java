package com.mindtree.assign1.service;

import java.util.Set;

import com.mindtree.assign1.entity.Employee;

public interface EmployeeService {
	 int addEmployee(Employee employee);
     Employee getEmployee(int employeeNo);
     void deleteEmployee(int employeeNo);
     void updateEmployee(Employee employee);
     Set<Employee> getAllEmployess();

}
