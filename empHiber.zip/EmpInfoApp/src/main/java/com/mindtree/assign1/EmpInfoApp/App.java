package com.mindtree.assign1.EmpInfoApp;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.Set;

import com.mindtree.assign1.entity.Department;
import com.mindtree.assign1.entity.Employee;
import com.mindtree.assign1.service.DepartmentService;
import com.mindtree.assign1.service.EmployeeService;
import com.mindtree.assign1.service.serviceImpl.DepartmentServiceImpl;
import com.mindtree.assign1.service.serviceImpl.EmployeeServiceImpl;

public class App 
{
	EmployeeService es=new EmployeeServiceImpl();
	DepartmentService ds=new DepartmentServiceImpl();
	
	
    public static void main( String[] args )
    { 
    	
    
    	App ap=new App();
    	Scanner sc=new Scanner(System.in);
    	
    	do {
    		
    		/*Department d=new Department(51, "IT");
    		Department d1=new Department(52,"IMTS");
    		Department d2=new Department(53,"Mangement");
    		ap.ds.createDepartment(d);
    		ap.ds.createDepartment(d1);
    		ap.ds.createDepartment(d2);*/
    		
    		System.out.println("Enter From below option");
    		System.out.println("1.insert 2.GetEmployeeById 3.Delete 4.Update 5.getAllEmployee 6.create dept 7.Exit");
    		int no=sc.nextInt();
    		switch(no) {
    		case 1:
    			Employee e=new Employee();
    			System.out.println("Enter Employee No");
    			e.setEmployeeNo(sc.nextInt());
    			sc.nextLine();
    			System.out.println("Enter name");
    			e.setEmployeeName(sc.nextLine());
    			System.out.println("Enter email");
    			e.setEmail(sc.nextLine());
    			System.out.println("Enter the date ");
    			String date=sc.nextLine();
    			Date date1 = null;
    			SimpleDateFormat df=new SimpleDateFormat("dd-MM-yyyy");
    			try {
					date1=df.parse(date);
				} catch (ParseException e2) {
					e2.printStackTrace();
				}
    			e.setDateofBirth(date1);
    			
    			System.out.println("Enter the salary");
    			e.setSalary(sc.nextDouble());
    			System.out.println("Enter the department id");
    			int depno=sc.nextInt();
    			Department department=ap.ds.getDeptById(depno);
    			if(department==null) {
    				System.out.println("department not available");
    				break;
    			}
    			else {
    			e.setDepartment(department);
    			}
    			//ap.ds.addEmployeeToDepartment(e, department);
    		
    			
    			ap.es.addEmployee(e);
    			break;
    		case 2:
    			System.out.println("Enter the employee id");
    			int id=sc.nextInt();
    			Employee ename=ap.es.getEmployee(id);
    			System.out.println(ename.getEmployeeName());
    			break;
    		case 3:
    			System.out.println("Enter the employee id");
    			int id1=sc.nextInt();
    			ap.es.deleteEmployee(id1);
    			
    			break;
    		case 4:
    		       Employee empll=new Employee();
    		       System.out.println("Enter id for update");
    		       int id2=sc.nextInt();
    		       System.out.println("Enter the name to update");
    		       sc.nextLine();
    		       String newname=sc.nextLine();
    		       empll.setEmployeeName(newname);
    		       empll.setEmployeeNo(id2);
    		       ap.es.updateEmployee(empll);
    			break;
    		case 5:
    			Set<Employee> emplist=ap.es.getAllEmployess();
    			for (Employee employee : emplist) {
					System.out.println(employee);
				}
    			break;
    		case 6:
    			System.out.println("Enter the depNo");
    			int deptno=sc.nextInt();
    			System.out.println("enter the depName");
    			String name=sc.next();
    			Department d=new Department();
    			d.setDeptNo(deptno);
    			d.setDeptName(name);
    			ap.ds.createDepartment(d);
    			break;
    			
    		case 7:
    			System.exit(0);
    			break;
    		}

    		
    	}while(true);
    	
    	
/*       Employee e=new Employee(13, "rameesh", "ramesh@gamil.com", null, 60000);
       Employee e1=new Employee(12, "mukesh", "mukesh@gamil.com", null, 50000);*/
      //ap.es.addEmployee(e);
      //ap.es.getEmployee(11);
      // ap.es.deleteEmployee(11);
 
       
      
      
    }
}
