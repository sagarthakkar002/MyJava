package com.mindtree.assign1.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
@Entity
public class Employee {
	@Id
	private int employeeNo;
	private String employeeName;
	private String email;
	private Date dateofBirth;
	private double salary;
	@ManyToOne/*(fetch=FetchType.LAZY)*/
	Department department;
	
	
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Employee(int employeeNo, String employeeName, String email, Date dateofBirth, double salary) {
		super();
		this.employeeNo = employeeNo;
		this.employeeName = employeeName;
		this.email = email;
		this.dateofBirth = dateofBirth;
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	public int getEmployeeNo() {
		return employeeNo;
	}
	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDateofBirth() {
		return dateofBirth;
	}
	public void setDateofBirth(Date dateofBirth) {
		this.dateofBirth = dateofBirth;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
/*	@Override
	public String toString() {
		return "Employee [employeeNo=" + employeeNo + ", employeeName=" + employeeName + ", email=" + email
				+ ", dateofBirth=" + dateofBirth + ", salary=" + salary+ " department"+department+"]";
	}*/
	
	


}
