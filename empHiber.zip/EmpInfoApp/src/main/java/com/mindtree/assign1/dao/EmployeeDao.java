package com.mindtree.assign1.dao;

import java.util.Set;

import com.mindtree.assign1.entity.Employee;

public interface EmployeeDao {
     int addEmployee(Employee employee);
     Employee getEmployee(int employeeNo);
     void deleteEmployee(int employeeNo);
     void updateEmployee(Employee employee);
     Set<Employee> getAllEmployess();
}
