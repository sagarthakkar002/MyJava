package com.mindtree.assign1.dao.daoImpl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mindtree.assign1.dao.DepartmentDao;
import com.mindtree.assign1.entity.Department;
import com.mindtree.assign1.entity.Employee;
import com.mindtree.assign1.util.DbUtility;

public class DepartmentDaoImpl implements DepartmentDao {
	Session session = DbUtility.getSession();

	public void createDepartment(Department department) {

		Transaction tx = session.beginTransaction();
		session.save(department);
		tx.commit();

	}

	public void addEmployeeToDepartment(Employee emp, Department dept) {

	}

	public void removeEmployeeToDepartment(Employee emp, Department dept) {
		// TODO Auto-generated method stub

	}

	public Set<Employee> getEmployees() {

		return null;
	}

	public Department getDeptById(int deptNo) {
		Session s1 = DbUtility.getSession();
		Transaction tx = s1.beginTransaction();
		Department d = s1.get(Department.class, deptNo);
		tx.commit();
		s1.close();
		/* System.out.println(d); */
		return d;
	}

	public void deleteDept(int deptNo) {
		Session s = DbUtility.getSession();
		Transaction tx = s.beginTransaction();
		Department d = getDeptById(deptNo);
		s.delete(d);
		tx.commit();
		s.close();

	}

	public Set<Department> getAllDepts() {
		Session s2 = DbUtility.getSession();
		Transaction tx = s2.beginTransaction();
		String query = "select * from department";
		List<Department> listDept = s2.createNativeQuery(query).addEntity(Department.class).list();
		
		/*for (Department department : listDept) {
			System.out.println(department);
		}*/
		Set<Department> dset = new HashSet<Department>(listDept);

		return dset;
	}

}
