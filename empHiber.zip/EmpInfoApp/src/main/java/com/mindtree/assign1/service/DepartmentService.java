package com.mindtree.assign1.service;

import java.util.Set;

import com.mindtree.assign1.entity.Department;
import com.mindtree.assign1.entity.Employee;

public interface DepartmentService {
	void createDepartment(Department department);
	void addEmployeeToDepartment(Employee emp,Department dept);
	void removeEmployeeToDepartment(Employee emp,Department dept);
	Set<Employee> getEmployees();
	Department getDeptById(int deptNo);

}
