package com.mindtree.assign1.service.serviceImpl;

import java.util.Set;

import com.mindtree.assign1.dao.EmployeeDao;
import com.mindtree.assign1.dao.daoImpl.EmployeeDaoImpl;
import com.mindtree.assign1.entity.Employee;
import com.mindtree.assign1.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService{
    EmployeeDao edao=new EmployeeDaoImpl();
	public int addEmployee(Employee employee) {
		return edao.addEmployee(employee);
		
	}

	public Employee getEmployee(int employeeNo) {
		return edao.getEmployee(employeeNo);
	}

	public void deleteEmployee(int employeeNo) {
		edao.deleteEmployee(employeeNo);
	
		
	}

	public void updateEmployee(Employee employee) {
		edao.updateEmployee(employee);
	}

	public Set<Employee> getAllEmployess() {
		
		return edao.getAllEmployess();
	}

	

}
