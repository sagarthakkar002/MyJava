package com.mindtree.assign1.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.assign1.entity.Department;
import com.mindtree.assign1.entity.Employee;

public class DbUtility {
    public static Session getSession(){
    	
    	Configuration con=new Configuration().configure().addAnnotatedClass(Employee.class).addAnnotatedClass(Department.class);
		SessionFactory sf=con.buildSessionFactory();
		Session session=sf.openSession();
		return session;
		
    	 
     }
}
