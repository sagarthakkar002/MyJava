package com.mindtree.assign1.dao;

import java.util.Set;

import com.mindtree.assign1.entity.Department;
import com.mindtree.assign1.entity.Employee;

public interface DepartmentDao {
	void createDepartment(Department department);
	void addEmployeeToDepartment(Employee emp,Department dept);
	void removeEmployeeToDepartment(Employee emp,Department dept);
	Set<Employee> getEmployees();
	Department getDeptById(int deptNo);

}
