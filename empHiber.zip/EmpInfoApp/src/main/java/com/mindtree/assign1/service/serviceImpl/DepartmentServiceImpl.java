package com.mindtree.assign1.service.serviceImpl;

import java.util.Set;

import com.mindtree.assign1.dao.DepartmentDao;
import com.mindtree.assign1.dao.daoImpl.DepartmentDaoImpl;
import com.mindtree.assign1.entity.Department;
import com.mindtree.assign1.entity.Employee;
import com.mindtree.assign1.service.DepartmentService;

public class DepartmentServiceImpl implements DepartmentService{
	 DepartmentDao depdao=new DepartmentDaoImpl();

	public void createDepartment(Department department) {
          depdao.createDepartment(department);
	}

	public void addEmployeeToDepartment(Employee emp, Department dept) {
		// TODO Auto-generated method stub
		
	}

	public void removeEmployeeToDepartment(Employee emp, Department dept) {
		// TODO Auto-generated method stub
		
	}

	public Set<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public Department getDeptById(int deptNo) {
		
		return depdao.getDeptById(deptNo);
	}

}
