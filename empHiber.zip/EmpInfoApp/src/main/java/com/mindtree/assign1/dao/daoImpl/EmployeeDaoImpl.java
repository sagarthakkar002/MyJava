package com.mindtree.assign1.dao.daoImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mindtree.assign1.dao.EmployeeDao;
import com.mindtree.assign1.entity.Employee;
import com.mindtree.assign1.util.DbUtility;

public class EmployeeDaoImpl implements EmployeeDao{
	Session session=DbUtility.getSession();
	public int addEmployee(Employee employee) {
		Transaction tx=session.beginTransaction();
		session.save(employee);
		tx.commit();
		return 0;

	}

	public Employee getEmployee(int employeeNo) {

		Transaction tx=session.beginTransaction();
		String query="from Employee e where e.employeeNo=:employeeNo";
		Query q=session.createQuery(query);
		q.setParameter("employeeNo", employeeNo);
		Employee e=(Employee) q.getSingleResult();
		//System.out.println(e.getEmployeeName());
		tx.commit();
		
		/*session.close();*/
		/*List<Employee> empl=new ArrayList<Employee>();
		empl=q.list();
		for (Employee employee : empl) {
			System.out.println(employee.getEmployeeName());
		}*/

		return e;
	}

	public void deleteEmployee(int employeeNo) {
		Employee e=getEmployee(employeeNo);
		Transaction tx=session.beginTransaction();
		session.delete(e);
		tx.commit();



	}

	public void updateEmployee(Employee employee) {
		Transaction tx=session.beginTransaction();
		String query="update Employee e set e.employeeName=:employeeName where e.employeeNo=:employeeNo";
		Query q=session.createQuery(query);
		q.setParameter("employeeName", employee.getEmployeeName());
		q.setParameter("employeeNo", employee.getEmployeeNo());
		int i=q.executeUpdate();
		tx.commit();
		System.out.println(i);

	}

	public Set<Employee> getAllEmployess() {
		Transaction tx=session.beginTransaction();
		String query="from Employee";
		Query q=session.createQuery(query);
		List<Employee> emplist=q.list();
		Set<Employee> empset= new HashSet<Employee>(emplist) ;
		tx.commit();
		return empset;
	}
	

}
