package com.mindtree.p1;

import java.util.Comparator;

public class ComapreByPname implements Comparator<Product> {

	public int compare(Product p1, Product p2) {
	
		return p1.getProductname().compareTo(p2.getProductname());
	}

}
