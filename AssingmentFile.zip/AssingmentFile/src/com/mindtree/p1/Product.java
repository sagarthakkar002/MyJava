package com.mindtree.p1;

public class Product implements Comparable<Product>{
     private int productid;
     private String productname;
     private double price;
     private String category;
     public Product() {
		// TODO Auto-generated constructor stub
	}
     
	public Product(int productid, String productname, double price, String category) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.price = price;
		this.category = category;
	}

	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public int compareTo(Product p) {
		return this.getProductname().compareTo(p.getProductname());
	}
     
     
}
