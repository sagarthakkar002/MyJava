package com.mindtree.p1;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		String temp="";
		List<Product> plist=new ArrayList<Product>();
		try(BufferedReader br=new BufferedReader(new FileReader("product.txt"))) {
			while((temp=br.readLine())!=null) {
				String[] arr=temp.split(",");
				Product p=new Product();
				for (String string : arr) {
					p=new Product(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2]), arr[3]);
				}
				plist.add(p);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		for (Product product : plist) {
			System.out.println(product.getProductid()+"\t"+product.getProductname()+"          "+
					product.getPrice()+" "+product.getCategory());
		}
		System.out.println("enter product");
		Scanner sc=new Scanner(System.in);
		String proname=sc.next();
		ProductOp obj=new ProductOp();
		List<Product> psortlist=obj.proList(proname,plist);
		ComapreByPname c=new ComapreByPname();

		//Collections.sort(psortlist);
		Collections.sort(psortlist,c);
		for (Product product : psortlist) {
			System.out.println(product.getProductid()+
					"\t"+product.getProductname()+"\t"+
					product.getCategory()+"\t"+product.getPrice());
		}


	}

}
