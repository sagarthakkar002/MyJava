package com.mindtree.p1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class ProductOp {
     ArrayList<Product> proList(String s,List<Product> temp){
    	ArrayList<Product> splist=new ArrayList<Product>();
    	for (Product product : temp) {
    		String ptemp=product.getCategory().trim();
			if(ptemp.equals(s)) {
				splist.add(product);
			}
		}
    /*	for (Product product : splist) {
			System.out.println(product.getProductid()+
					" "+product.getProductname());
		}*/
		return splist;
    	 
     }
}
