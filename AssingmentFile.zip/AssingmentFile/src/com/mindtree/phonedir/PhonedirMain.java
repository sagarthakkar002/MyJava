package com.mindtree.phonedir;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PhonedirMain {
    public static void main(String[] args) throws IOException {
		System.out.println("Welcome to online phone Directory");
		PhonedirMethod pobj=new PhonedirMethod();
		
		do {
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("1.Enter phone entry u \n2. Look Up \n3.Display \n4.exit");
			System.out.println("enter choice");
			int no=Integer.parseInt(br.readLine());
			System.out.println();
			switch(no) {
			case 1:
				pobj.addEntry();
				break;
			case 2:
				pobj.searchEntry();
				break;
			case 3:
				pobj.displayDir();
				break;
			case 4:
				System.exit(0);
				
			}
		}while(true);
	}
}
