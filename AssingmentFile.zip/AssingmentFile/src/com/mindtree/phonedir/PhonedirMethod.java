package com.mindtree.phonedir;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class PhonedirMethod {
    Map<String,Long> maplist=new HashMap<>();
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

    void addEntry() throws IOException {
    	System.out.println("enter name");
    	String name=br.readLine();
    	System.out.println("enter phone number");
    	Long phoneNo=Long.parseLong(br.readLine());
    	maplist.put(name, phoneNo);
    	//System.out.println(maplist);
    }
    
    void searchEntry() throws IOException {
    	System.out.println("enter the name to search for");
    	String name=br.readLine();
    	for (Map.Entry<String, Long> it : maplist.entrySet()) {
			String na=it.getKey();
			if(na.equals(name)) {
				System.out.println(it.getKey() +" -> "+it.getValue());
			}
		}
    }
    void displayDir() {
    	System.out.println("All records");
    	for (Map.Entry<String, Long> it : maplist.entrySet()) {
			System.out.println(it.getKey() +" -> "+it.getValue());
			}
		}
    	//System.out.println(maplist);
    
}
    


