import React from 'react';

import './App.scss';
import WallPage from './components/Page/WallPage';


function App() {
  return (
    <div className="App">
      <WallPage />
    </div>
  );
}

export default App;
