import React, { Component } from 'react'
import { Row, Col, Container } from 'react-bootstrap'
import StepsCounterHead from '../StepsCount/StepsCounterHead'
import Tweetcomp from '../TweetComponent/Tweetcomp'
import VideoCard from '../VideoCards/VideoCards'
import Participant from '../Participant/Participant'
import Leader from '../Leader/Leader'

class WallPage extends Component {
    render() {
        return (
            <div>
                <div>
                    <Container fluid>
                        <Row id="head-row">
                            <Col xs={12} sm={12} md={12} lg={12}>
                                <StepsCounterHead />
                            </Col>
                        </Row>
                        <Container>
                        <Row id="middle-row">
                            <Col xs={12} sm={6} md={6} lg={6}>
                                <Row>
                                    <Col xs={12} sm={6} md={6} lg={6}>
                                        <VideoCard
                                            url="https://www.youtube.com/embed/OsrtR5wA_zw"
                                            id='first-video' />
                                    </Col>
                                    <Col xs={12} sm={6} md={6} lg={6}>
                                        <VideoCard
                                            url="https://www.youtube.com/embed/qx16WKHiXVw"
                                            id='second-video' />
                                    </Col>
                                </Row>

                            </Col>
                            <Col xs={12} sm={6} md={6} lg={6}>
                                <Row>
                                    <Tweetcomp id="card-tweet" />
                                </Row>
                            </Col>

                        </Row>
                        </Container>

                        <Container>
                        <Row id="third-row">
                            <Col xs={12} sm={6} md={6} lg={6}>
                                <Participant />
                            </Col>
                            <Col xs={12} sm={6} md={6} lg={6}>
                                <Leader/>
                        </Col>
                        </Row>
                        </Container>
                    </Container>


                </div>
            </div>
        )
    }
}
export default WallPage
