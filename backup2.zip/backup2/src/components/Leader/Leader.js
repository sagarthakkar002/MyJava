import React from 'react'
import { Row, Col } from 'react-bootstrap'
import axios from 'axios'
class Leader extends React.Component {
    constructor(props) {
        super(props)
        this.interval = null
        this.state = {
            toprunnersglobally: null,
            toprunnerslocally: null
        }
        console.log(this.state.toprunnersglobally);
    }
    update = () => {
        axios.get("http://mt20api.westeurope.cloudapp.azure.com:7080/digitalWall/getLeaderBoardDetails/Bangalore")
            .then(res => {
                const LeaderBoard = res.data;
               

                console.log(LeaderBoard.leaderBoardDetails.topRunnersGlobally)
                console.log(LeaderBoard.leaderBoardDetails.topRunnersLocally)
                this.setState({
                    toprunnersglobally: LeaderBoard.leaderBoardDetails.topRunnersGlobally,
                    toprunnerslocally: LeaderBoard.leaderBoardDetails.topRunnersLocally

                })
            })

    }
    componentDidMount() {
        this.interval = setInterval(this.update, 1000)
    }
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    render() {
        if(!this.state.toprunnerslocally){
            return null
        }
        else{
        return (
            <div id="leader-container">
                <Row>
                    <Col xs={12} sm={6} md={6} lg={6} id="local-column" >
                        <Row>
                            <Col xs={12} sm={12} md={12} lg={12} id="first-panel">
                                <div class="panel panel-default" >
                                    <div class="panel-body">LOCAL</div>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={5} md={5} lg={5} >
                                <div className="leader-info">
                                    <span className="leader-details">Rajat</span>
                                    <span className="leader-details" id="leader-city">Bangalore</span>
                                </div>
                            </Col>
                            <Col xs={12} sm={4} md={4} lg={4} >
                                <div className="leader-info"><span>1,519,411</span></div>
                            </Col>
                            <Col xs={12} sm={3} md={3} lg={3} >
                                <div className="leader-info"><span>1st</span></div>
                            </Col>

                        </Row>
                        <Row>
                            <Col xs={12} sm={5} md={5} lg={5} >
                                <div className="leader-info">
                                    <span className="leader-details">Vishal</span>
                                    <span className="leader-details" id="leader-city">Pune</span>
                                </div>
                            </Col>
                            <Col xs={12} sm={4} md={4} lg={4} >
                                <div className="leader-info"><span>1,512,210</span></div>
                            </Col>
                            <Col xs={12} sm={3} md={3} lg={3} >
                                <div className="leader-info"><span>2nd</span></div>
                            </Col>

                        </Row>

                    </Col>


                    <Col xs={12} sm={6} md={6} lg={6} >
                        <Row>
                            <Col xs={12} sm={12} md={12} lg={12} id="second-panel">
                                <div class="panel panel-default" >
                                    <div class="panel-body">GLOBAL</div>
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={5} md={5} lg={5} >
                                <div className="leader-info">
                                    <span className="leader-details">{this.state.toprunnersglobally[0].name}</span>
                                    <span className="leader-details" id="leader-city">{this.state.toprunnersglobally[0].location}</span>
                                </div>
                            </Col>
                            <Col xs={12} sm={4} md={4} lg={4} >
                                <div className="leader-info"><span>{this.state.toprunnersglobally[0].steps}</span></div>
                            </Col>
                            <Col xs={12} sm={3} md={3} lg={3} >
                                <div className="leader-info"><span>{this.state.toprunnersglobally[0].rank}st</span></div>
                            </Col>

                        </Row>
                        <Row>
                            <Col xs={12} sm={5} md={5} lg={5} >
                                <div className="leader-info">
                                    <span className="leader-details">{this.state.toprunnersglobally[1].name}</span>
                                    <span className="leader-details" id="leader-city">{this.state.toprunnersglobally[1].loaction}</span>
                                </div>
                            </Col>
                            <Col xs={12} sm={4} md={4} lg={4} >
                                <div className="leader-info"><span>{this.state.toprunnersglobally[1].steps}</span></div>
                            </Col>
                            <Col xs={12} sm={3} md={3} lg={3} >
                                <div className="leader-info"><span>{this.state.toprunnersglobally[1].rank}</span></div>
                            </Col>

                        </Row>


                    </Col>
                </Row>

            </div>


        )
    }
}
}
export default Leader