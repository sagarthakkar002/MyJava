import React from 'react'

const VideoCards = (props) => {
    return (
        <div class="video-display-div">
            <div class="embed-responsive embed-responsive-4by3 video-display">
                <iframe title="unique" class="embed-responsive-item" src={props.url}></iframe>
            </div>
        </div>
    )
}

export default VideoCards
