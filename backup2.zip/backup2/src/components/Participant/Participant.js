import React from 'react';
import { Row, Col, Container } from 'react-bootstrap';
import first from '../../PhotsMindtree/first.jpg';
import second from '../../PhotsMindtree/second.jpg';

import firebase from 'firebase/app';

import 'firebase/storage';

const config = {
    apiKey: 'AIzaSyCFqWzGXFZOk2GyE1RB7vQgSVYSFPkNVIA',
    authDomain: 'mindtree20.firebaseapp.com',
    projectId: 'mindtree20',
    storageBucket: 'mindtree20.appspot.com'

};

firebase.initializeApp(config);

const Participant = () => {

    const imageURLs = [];
    const storage = firebase.storage();

    console.log('====================================');
    storage.ref('images').listAll().then((data) => {
        console.error(data);
        data.items.map((ele) => {

            storage.ref(ele.fullPath).getDownloadURL().then((url) => {
                console.error(url);

                imageURLs.push(url);
                console.log(imageURLs);
            });
        });
    });

    console.log('====================================');

    console.log('====================================');
    console.log(storage);
    console.log('====================================');
    return (
        <>
            <Row>
                <Col xs={12} sm={12} md={12} lg={12}>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <span>Pictures of the Participants</span>
                        </div>
                    </div>
                </Col>
            </Row>
            <Row>
                <Container>
                    <Row>
                        <Col xs={12} md={4} sm={4} lg={4} >
                            <div class="display-details">

                                <img className="img-display" src={first} alt="image1" />
                                <span>Dummy text</span>
                            </div>

                        </Col>
                        <Col xs={12} md={4} sm={4} lg={4}>
                            <div className="display-details">
                                <img src={second} alt="image1" />
                                <span>Dummy text</span>
                            </div>
                        </Col>
                        <Col xs={12} md={4} sm={4} lg={4}>
                            <div className="display-details">
                                <img src={second} alt="image1" />
                                <span>Dummy text</span>
                            </div>
                        </Col>
                    </Row>
                </Container>
                <Container>
                    <Row>
                        <Col xs={12} md={4} sm={4} lg={4} >
                            <div className="display-details">
                                <img src={first} alt="image1" />
                                <span>Dummy text</span>
                            </div>
                        </Col>
                        <Col xs={12} md={4} sm={4} lg={4}>
                            <div className="display-details">
                                <img src={first} alt="image1" />
                                <span>Dummy text</span>
                            </div>
                        </Col>
                        <Col xs={12} md={4} sm={4} lg={4}>
                            <div className="display-details">
                                <img src={first} alt="image1" />
                                <span>Dummy text</span>
                            </div>
                        </Col>

                    </Row>
                </Container>
            </Row>
        </>
    )
}

export default Participant
