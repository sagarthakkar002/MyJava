import React, { Component } from 'react'
import axios from 'axios'
class StepsCounterHead extends Component {
    constructor(props) {
        super(props)
        this.interval = null

        this.state = {
            response: '',
        }
    }
    update = () => {
        axios.get("http://mt20api.westeurope.cloudapp.azure.com:7080/digitalWall/steps/getTotalStepsCount")
            .then(res => {
                const counterHead = res.data;
                let steps=counterHead.totalStepsDetails.totalStepsAchieved
    
                steps=steps.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                   
                console.log(res)
                this.setState({
                    response: steps
                })
            })

    }
    componentDidMount() {
        this.interval = setInterval(this.update, 1000000)
    }
    componentWillUnmount() {
        clearInterval(this.interval);
    }

    render() {
        console.log(this.state.response)
        return (
            <div>
                <header>
                    <div className="d-flex justify-content-center count-steps-div ">
                        <span id="stepscount">{this.state.response}</span>
                        <span id="stepscount-text">Steps achieved globally</span>
                    </div>
                </header>

            </div>)
    }





}

export default StepsCounterHead
