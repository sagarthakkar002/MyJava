import React from 'react';
import { TwitterTweetEmbed } from 'react-twitter-embed';





const Tweetcomp = (props) => {

    const TweetJs = {
        ListTweetsOnUserTimeline: function (screenName, callback) {
            TweetJs._callApi({
                Action: "ListTweetsOnUserTimeline",
                ScreenName: screenName
            },
                callback);
        },
        Search: function (query, callback) {
            TweetJs._callApi({
                Action: "Search",
                Query: query
            }, callback);
        },
        _callApi: function (request, callback) {
            var xhr = new XMLHttpRequest();
            URL = "https://www.tweetjs.com/API.aspx";
            xhr.open("POST", URL);
            xhr.onreadystatechange = function () {
                if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                    callback(JSON.parse(xhr.response));
                }
            }
            xhr.send(JSON.stringify(request));
        }
    };

    TweetJs.Search('mindtree20', (res) => {
        console.log('====================================');
        console.log(res);
        console.log('====================================');
    });
    return (
        <div>
            <TwitterTweetEmbed
                tweetId={'1159851485917659136'}
            />
            <div class="card" id={props.id}>
                <div class="card-body">
                    <span class="text-align-left card-title">Tweets</span>
                    <hr></hr>
                    <img class="card-img-top" src="" alt="someone" />
                    <span class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</span>

                </div>
            </div>

        </div >
    )
}

export default Tweetcomp
