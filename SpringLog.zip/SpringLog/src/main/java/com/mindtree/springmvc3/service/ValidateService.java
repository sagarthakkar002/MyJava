package com.mindtree.springmvc3.service;

public interface ValidateService {
	public String validate(String name,int pass);
}
