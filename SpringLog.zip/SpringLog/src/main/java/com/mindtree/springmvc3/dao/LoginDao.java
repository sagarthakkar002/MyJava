package com.mindtree.springmvc3.dao;

import com.mindtree.springmvc3.model.Login;

public interface LoginDao {
	String insertDetail(Login l);
	Login getData(String userName);

}
