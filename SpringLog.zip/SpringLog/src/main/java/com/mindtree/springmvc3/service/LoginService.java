package com.mindtree.springmvc3.service;


import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mindtree.springmvc3.model.Login;


public interface LoginService {
	String insertDetail(Login l);
	Login getData(String userName);

}
