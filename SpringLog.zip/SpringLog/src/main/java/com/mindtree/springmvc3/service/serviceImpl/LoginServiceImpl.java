package com.mindtree.springmvc3.service.serviceImpl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mindtree.springmvc3.dao.LoginDao;
import com.mindtree.springmvc3.model.Login;
import com.mindtree.springmvc3.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
    private LoginDao dao;
	
	@Transactional
	public String insertDetail(Login l) {
		return dao.insertDetail(l);
	}

	public Login getData(String userName) {
		return dao.getData(userName);
	}

}
