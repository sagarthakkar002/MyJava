package com.mindtree.springmvc3.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.springmvc3.configuration.hiberconfing;
import com.mindtree.springmvc3.model.Login;
import com.mindtree.springmvc3.service.LoginService;

@Controller
public class LoginController {
	
	@RequestMapping("/")
	public ModelAndView Data() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index");
		return mv;

	}
	
	@RequestMapping("/login")
	public ModelAndView getData(@RequestParam("username")String name,
			@RequestParam("password")int password) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ap=new AnnotationConfigApplicationContext(hiberconfing.class);
		LoginService ls=ap.getBean(LoginService.class);
		Login l=ap.getBean(Login.class);
		Login loginobj=ls.getData(name);
		int pass=loginobj.getUserPassword();
		if(pass==password) {
			mv.setViewName("addEmployee");
			return mv;
		}
		else {
			mv.setViewName("index");
			return mv;
		}
	

		
	}
	@RequestMapping("/SignUpPage")
	public ModelAndView getData() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("NewLogin");
		return mv;

	}
	
	@RequestMapping("/SignUp")
	
	public ModelAndView SignUp(@RequestParam("username")String name,
			@RequestParam("password")int password) {
		ModelAndView mv=new ModelAndView();
		System.out.println(name +" "+password);
		ApplicationContext ap=new AnnotationConfigApplicationContext(hiberconfing.class);
		LoginService ls=ap.getBean(LoginService.class);
		Login l=ap.getBean(Login.class);
		l.setUserName(name);
		l.setUserPassword(password);
		ls.insertDetail(l);
		mv.setViewName("index");

		return mv;

}
}