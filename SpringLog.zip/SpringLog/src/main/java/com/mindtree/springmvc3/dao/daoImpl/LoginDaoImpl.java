package com.mindtree.springmvc3.dao.daoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.mindtree.springmvc3.dao.LoginDao;
import com.mindtree.springmvc3.model.Login;

@Repository
public class LoginDaoImpl implements LoginDao{
	@Autowired
	private HibernateTemplate hibernatetemplate;
    
	public String insertDetail(Login l) {
		hibernatetemplate.save(l);
		return "inserted";
	}

	public Login getData(String userName) {
		
		Login l=hibernatetemplate.get(Login.class, userName);
		
		return l;
	}

}
