package com.mindtree.springmvc3.MainAppFile;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindtree.springmvc3.configuration.hiberconfing;
import com.mindtree.springmvc3.model.Login;
import com.mindtree.springmvc3.service.LoginService;

public class App {
	
	/*public static void main(String args[]) {
		
		ApplicationContext context=new AnnotationConfigApplicationContext(hiberconfing.class);
		LoginService ls=context.getBean(LoginService.class);
		Login l=context.getBean(Login.class);
		l.setUserName("sagar");
		l.setUserPassword(1234);
		//ls.insertDetail(l);
		
		Login lo=ls.getData("sagar");
		System.out.println(lo.getUserName()+"\t"+lo.getUserPassword());
	}*/

}
