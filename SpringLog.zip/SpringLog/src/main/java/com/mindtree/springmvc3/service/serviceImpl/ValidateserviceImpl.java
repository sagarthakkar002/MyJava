package com.mindtree.springmvc3.service.serviceImpl;

import com.mindtree.springmvc3.service.ValidateService;

public class ValidateserviceImpl  implements ValidateService {

	public String validate(String name, int pass) {

		
			String msg="";
			if(name.equals("sagar") && pass==12345) {
				/*System.out.println("in if");*/
				 msg=msg+"Login Succesful";
				
			}
			else {
				/*System.out.println("in else");*/
				msg=msg+"error";
			}
			return msg;
		}
	
		
	}


