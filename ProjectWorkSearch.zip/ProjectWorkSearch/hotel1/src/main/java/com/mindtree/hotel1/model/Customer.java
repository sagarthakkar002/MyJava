package com.mindtree.hotel1.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.mindtree.hotel1.Util.UtilServices;

@Entity
public class Customer {
	
	@Id
	private String customerId;
	@NotNull()
	private String customerName;
	@NotNull
	private String email;
	@NotNull
	private String password;
	@NotNull
	private String phoneNo;
	@NotNull
	private String city;
	@NotNull
	private String state;
	@NotNull
	private boolean logInWith;
	
	public Customer(String customerId) {
		super();
		this.customerId=customerId;
	}
	
	public Customer() {
		
	}


	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId() {
		this.customerId = "C"+UtilServices.customerIdGenerator();
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public boolean isLogInWith() {
		return logInWith;
	}

	public void setLogInWith(boolean logInWith) {
		this.logInWith = logInWith;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email
				+ ", password=" + password + ", phoneNo=" + phoneNo + ", city=" + city + ", state=" + state
				+ ", logInWith=" + logInWith + "]";
	}
	
	
	

}
