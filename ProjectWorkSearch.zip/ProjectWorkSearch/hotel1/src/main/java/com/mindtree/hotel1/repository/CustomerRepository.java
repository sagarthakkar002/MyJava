package com.mindtree.hotel1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.hotel1.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, String>{
     
}
