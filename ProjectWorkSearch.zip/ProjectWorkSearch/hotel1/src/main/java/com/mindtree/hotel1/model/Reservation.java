package com.mindtree.hotel1.model;


import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.mindtree.hotel1.Util.UtilServices;

@Entity
public class Reservation {
	
	@Id
	private String reservationId;
	@OneToOne
	@JoinColumn(name="customerId")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="hotelId")
	private Hotel hotel;
	private Date check_in;
	private Date check_out;
	private int no_room_booked;
	
	
	
	public Reservation() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Reservation(String reservationId, Customer customer, Hotel hotel, Date check_in, Date check_out,
			int no_room_booked) {
		super();
		this.reservationId = reservationId;
		this.customer = customer;
		this.hotel = hotel;
		this.check_in = check_in;
		this.check_out = check_out;
		this.no_room_booked = no_room_booked;
	}


	public String getReservationId() {
		return reservationId;
	}
	
	//remember to set in controller before saving
	public void setReservationId() {
		this.reservationId = "R"+UtilServices.reservationIdGenerator();
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	public Date getCheck_in() {
		return check_in;
	}
	public void setCheck_in(String check_in) {
		this.check_in = java.sql.Date.valueOf(check_in);
	}
	public String getCheck_out() {
		return check_out.toString();
	}
	public void setCheck_out(String check_out) {
		this.check_out = Date.valueOf(check_out);
	}
	public int getNo_room_booked() {
		return no_room_booked;
	}
	public void setNo_room_booked(int no_room_booked) {
		this.no_room_booked = no_room_booked;
	}

	@Override
	public String toString() {
		return "Reservation [reservationId=" + reservationId + ", customer=" + customer + ", hotel=" + hotel
				+ ", check_in=" + check_in + ", check_out=" + check_out + ", no_room_booked=" + no_room_booked + "]";
	}
	
	
	
	
	

}
