package com.mindtree.hotel1.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.hotel1.model.Customer;
import com.mindtree.hotel1.service.CustomerService;

@RestController
@CrossOrigin("*")
public class CustomerController {
	@Autowired
	CustomerService customerservice;
	
	@PostMapping("/verify")
	public ResponseEntity<String> verifyCustomer(@RequestBody String[] object) {
		//System.out.println(object[0]);
		//System.out.println(object[1]);
		String email=object[0];
		String password=object[1];
		Customer c=getAllCustomer().stream().filter(customer->customer.getEmail().equals(email)).filter(cust->cust.getPassword().equals(password)).findFirst().get();
		if(c!=null) {
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}
		else {
			return new ResponseEntity<String>("Failed", HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/customer")
	public ResponseEntity<String> addCustomer(@RequestBody Customer customer) {
		 if(customer!=null) {
		 customerservice.addCustomer(customer);
		   return new ResponseEntity<String>("Added Login Now", HttpStatus.OK);
		 }
		 else {
			 return new ResponseEntity<String>("Failed", HttpStatus.BAD_REQUEST);
		 }
		 
	}
	
	@GetMapping("/customer/{customerId}")
	public Optional<Customer> getCustomerByCustomerId(@PathVariable String customerId) {
		return customerservice.getCustomerById(customerId);
		
	}
	
	public List<Customer> getAllCustomer(){
		return customerservice.getAllCustomer();
		
		
	}
	
	/*@GetMapping("/customer")
	public Customer getCustomer() {
		
	}*/
	
	

}
