package com.mindtree.hotel1.controller;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.hotel1.model.Hotel;
import com.mindtree.hotel1.model.HotelSortByPrice;
import com.mindtree.hotel1.service.HotelService;

@RestController
@CrossOrigin("*")
public class HotelController {

	@Autowired
	HotelService hotelservice;

	@RequestMapping(value = "/hotel", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void addHotel(@RequestBody Hotel hotel) {

		hotel.setHotelId();
		hotelservice.addHotel(hotel);
	}

	/*
	 * @RequestMapping(value="/hotel/{hotelId}", method=RequestMethod.GET) public
	 * Optional<Hotel> getHotelById(@PathVariable String hotelId) { return
	 * hotelservice.getHotelById(hotelId); }
	 */
	@RequestMapping(value = "/hotel", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Hotel> getAllHotel() {
		List<Hotel> listOfHotel = hotelservice.getAllHotel();
		return listOfHotel;
	}

	@RequestMapping(value = "/hotel/{hotelId}", method = RequestMethod.DELETE)
	public void deleteHotelById(@PathVariable String hotelId) {
		hotelservice.deleteHotelById(hotelId);
	}

	@PostMapping(value="/hotel/sorted/{city}",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Hotel> sortedHotel(@PathVariable String city) {
		System.out.println(" city"+city);
		List<Hotel> hlist = getAllHotel().stream().filter(hotel->hotel.getCity().equals(city)).collect(Collectors.toList());
		System.out.println(hlist);
		HotelSortByPrice obj1 = new HotelSortByPrice();
		Collections.sort(hlist, obj1);
		return hlist;

	}

	@PostMapping(value="/hotel/{city}",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Hotel> hotelByName(@PathVariable String city) {
//		System.out.println(city);
		List<Hotel> listofhotel= getAllHotel().stream().filter(hotel -> hotel.getCity().equals(city)).collect(Collectors.toList());
        return listofhotel;
	}

}
