package com.mindtree.hotel1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hotel1Application {

	public static void main(String[] args) {
		SpringApplication.run(Hotel1Application.class, args);
	}
}
