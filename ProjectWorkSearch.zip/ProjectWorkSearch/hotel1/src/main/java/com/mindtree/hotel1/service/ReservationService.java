package com.mindtree.hotel1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hotel1.model.Reservation;
import com.mindtree.hotel1.repository.ReservationRepository;

@Service
public class ReservationService {
	@Autowired
	ReservationRepository reservationrepo;
	
	
	public String setReservation(Reservation reservation) {
		reservation.setReservationId();
		reservationrepo.save(reservation);
		return "success";
		
	}
	public Optional<Reservation> getReservation(String reservationId) {
		return reservationrepo.findById(reservationId);
	}
	public List<Reservation> getAllReservation(){
		return reservationrepo.findAll();
	}

}
