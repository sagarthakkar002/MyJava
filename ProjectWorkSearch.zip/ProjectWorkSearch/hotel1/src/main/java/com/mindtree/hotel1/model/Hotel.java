package com.mindtree.hotel1.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.mindtree.hotel1.Util.UtilServices;

@Entity
public class Hotel {
	@Id
	@NotNull
	private String hotelId;
	private String hotelName;
	private String city;
	private double tariff;
	private int total_no_rooms;
	private int hotel_rating;
	
	public Hotel(String hotelId) {
		super();
		this.hotelId=hotelId;
	}
	
	public Hotel() {
		super();
	}

	public int getHotel_rating() {
		return hotel_rating;
	}

	public void setHotel_rating(int hotel_rating) {
		this.hotel_rating = hotel_rating;
	}

	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId() {
		this.hotelId = "H"+UtilServices.hotelIdGenerator();
		//System.out.println(this.hotelId);
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public double getTariff() {
		return tariff;
	}

	public void setTariff(double tariff) {
		this.tariff = tariff;
	}

	public int getTotal_no_rooms() {
		return total_no_rooms;
	}

	public void setTotal_no_rooms(int total_no_rooms) {
		this.total_no_rooms = total_no_rooms;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", city=" + city + ", tariff=" + tariff
				+ ", total_no_rooms=" + total_no_rooms + ", hotel_rating=" + hotel_rating + "]";
	}

	

}
