package com.mindtree.hotel1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hotel1.model.Customer;
import com.mindtree.hotel1.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerrepo;
	
	public String addCustomer(Customer customer) {
		customer.setCustomerId();
		customerrepo.save(customer);
		return "success";
	}
	
	public Optional<Customer> getCustomerById(String customerId) {
		return customerrepo.findById(customerId);
	}
	
	public List<Customer> getAllCustomer(){
		List<Customer> customerlist=customerrepo.findAll();
		return customerlist;
		
	}

}
