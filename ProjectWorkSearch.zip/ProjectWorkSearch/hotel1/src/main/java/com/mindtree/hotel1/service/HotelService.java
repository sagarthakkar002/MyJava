package com.mindtree.hotel1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hotel1.model.Hotel;
import com.mindtree.hotel1.model.Reservation;
import com.mindtree.hotel1.repository.HotelRepository;

@Service
public class HotelService {
	@Autowired
	HotelRepository hotelrepo;
	
	public void addHotel(Hotel hotel) {
		hotelrepo.save(hotel);
	}
	
	public Optional<Hotel> getHotelById(String hotelId) {
		return hotelrepo.findById(hotelId);
	}
	public List<Hotel> getAllHotel(){
		List<Hotel> hlist= hotelrepo.findAll();
		return hlist;
	}
	public void deleteHotelById(String hotelId) {
		 hotelrepo.deleteById(hotelId);
	}
	

}
