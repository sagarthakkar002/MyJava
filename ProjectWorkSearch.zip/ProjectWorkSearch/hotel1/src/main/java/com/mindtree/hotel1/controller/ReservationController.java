package com.mindtree.hotel1.controller;

import java.sql.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.hotel1.model.Customer;
import com.mindtree.hotel1.model.Hotel;
import com.mindtree.hotel1.model.Reservation;
import com.mindtree.hotel1.service.CustomerService;
import com.mindtree.hotel1.service.HotelService;
import com.mindtree.hotel1.service.ReservationService;

@RestController
@CrossOrigin("*")
public class ReservationController {
	@Autowired
	ReservationService reservationservice;
	@Autowired
	HotelService hotelserv;
	@Autowired
    CustomerService customerserv;
	
	@PostMapping(value="/reservation/add",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String setReservation(@RequestBody Reservation reservation) {
		System.out.println(reservation+" reservation");
		  reservationservice.setReservation(reservation);
		  return reservation.getReservationId();
		 
	}
	@GetMapping("/reservation/{reservationId}")
	public Optional<Reservation> getRevesion(@PathVariable String reservationId) {
		return reservationservice.getReservation(reservationId);
	}
	@GetMapping("/reservation")
	public List<Reservation> getAllRevision(){
		return reservationservice.getAllReservation();
		
	}
	
	
	@PostMapping(value="/reservation/check",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Reservation> checkAvailability(@RequestBody String[] input){
		System.out.println("Hi");
		String checkin=input[0];
		System.out.println(checkin);
		String checkout=input[1];
		System.out.println(checkout);
		String hotelname=input[2];
		System.out.println(hotelname);
		int roomcount=Integer.parseInt(input[3]);
		System.out.println(roomcount);//count of room
		System.out.println(input[4]);//email
		
		Hotel hotel=hotelserv.getAllHotel().stream().filter(hotel1->hotel1.getHotelName().equals(input[2])).findFirst().get();
	    Customer customer=customerserv.getAllCustomer().stream().filter(cust->cust.getEmail().equals(input[4])).findFirst().get();
		Reservation reserveBook=null;
		System.out.println(hotel.getCity());
		System.out.println(customer.getCustomerId());
		int count=0;
		if(hotel.getTotal_no_rooms()>=Integer.parseInt(input[3])) {
			System.out.println("Outer if");
			List<Reservation> reserve=reservationservice.getAllReservation().stream().filter(book->book.getHotel().getHotelId().equals(hotel.getHotelId())).collect(Collectors.toList());
			reserve.forEach(System.out::println);
			if(reserve.size()==0) {
				System.out.println("In size zero array");
				reserveBook=new Reservation();
				reserveBook.setCheck_in(input[0]);
				reserveBook.setCheck_out(input[1]);
				reserveBook.setNo_room_booked(roomcount);
				reserveBook.setCustomer(customer);
				reserveBook.setHotel(hotel);
				
				return new ResponseEntity<Reservation>(reserveBook, HttpStatus.OK);
			}
			count=hotel.getTotal_no_rooms();
			System.out.println(" total rooms"+count);
			for(Reservation reservation:reserve) {
				
				//System.out.println("room there "+count);
				count=count-reservation.getNo_room_booked();
				System.out.println("left till date "+count);
				 long timeduration=Date.valueOf(input[0]).getTime()-Date.valueOf(reservation.getCheck_out()).getTime();
			     long daydifference = TimeUnit.MILLISECONDS.toDays(timeduration);
			     System.out.println(daydifference+"day difference");
			     if(daydifference>0){
			    	 count=count+reservation.getNo_room_booked();
			    	 System.out.println("room added after leaving "+count);
			     }else {
			    	 //return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
			     }
			 }
			if(count>=Integer.parseInt(input[3])) {
				System.out.println("soon in database");
				reserveBook=new Reservation();
				reserveBook.setCheck_in(input[0]);
				reserveBook.setCheck_out(input[1]);
				reserveBook.setNo_room_booked(roomcount);
				reserveBook.setCustomer(customer);
				reserveBook.setHotel(hotel);
				System.out.println("hi hi hi bye"+reserveBook);
				return new ResponseEntity<Reservation>(reserveBook, HttpStatus.OK);
			}
			else {
				System.out.println("first bad error");
				return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
			}
		}
		else {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
		
		//int daydifference=checkin-checkout;
		//long duration=Date.valueOf(input[0]).getTime()-Date.valueOf(b.getCheckOut()).getTime();
		//long diffInDays = TimeUnit.MILLISECONDS.toDays(duration);
		
		
	}
	
	

}
