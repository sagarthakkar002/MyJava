package com.mindtree.hotel1.model;

import java.util.Comparator;

public class HotelSortByPrice implements Comparator<Hotel>{

	@Override
	public int compare(Hotel h1, Hotel h2) {
		
		if(h1.getTariff()-h2.getTariff()>0) {
			return 1;
		}
		else if(h1.getTariff()-h2.getTariff()<0) {
			return -1;
		}
		return 0;
	}

}
