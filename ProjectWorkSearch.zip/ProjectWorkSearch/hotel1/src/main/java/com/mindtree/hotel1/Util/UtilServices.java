package com.mindtree.hotel1.Util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class UtilServices {
	
    //generate Id for Hotel 
	public static int hotelIdGenerator() {
		int hotelId = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader("count.txt"));
			String temp;
			while ((temp = br.readLine()) != null) {
				hotelId = Integer.parseInt(temp.trim());
				hotelId++;
				System.out.println(hotelId);
			}
			br.close();
			FileWriter fw = new FileWriter("count.txt");
			fw.write(String.valueOf(hotelId));
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return hotelId++;
	}
	
	//generate reservationId
	public static int reservationIdGenerator() {
		int reservationId = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader("ReservationIdCount.txt"));
			String temp;
			while ((temp = br.readLine()) != null) {
				reservationId = Integer.parseInt(temp.trim());
				reservationId++;
				//System.out.println(reservationId);
			}
			br.close();
			FileWriter fw = new FileWriter("ReservationIdCount.txt");
			fw.write(String.valueOf(reservationId));
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reservationId++;
	}
	
	//generate Customer Id
	public static int customerIdGenerator() {
		int customerId = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader("CustomerIdCount.txt"));
			String temp;
			while ((temp = br.readLine()) != null) {
				customerId = Integer.parseInt(temp.trim());
				customerId++;
				//System.out.println(customerId);
			}
			br.close();
			FileWriter fw = new FileWriter("CustomerIdCount.txt");
			fw.write(String.valueOf(customerId));
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return customerId++;
	}
	/*
	 * public static int findLastHotelId() { HotelService obj = null;
	 * List<Hotel>ListOfHotel=obj.getAllHotel(); String
	 * hotelId=ListOfHotel.get(ListOfHotel.size()).getHotelId(); return
	 * Integer.parseInt(hotelId.substring(1, 3)); }
	 */

	/*
	 * public static int lastId() {
	 * List<Hotel>ListOfHotel=hotelservice.getAllHotel(); String
	 * hotelId=ListOfHotel.get(ListOfHotel.size()).getHotelId(); return
	 * Integer.parseInt(hotelId.substring(1, 3)); }
	 */
}
