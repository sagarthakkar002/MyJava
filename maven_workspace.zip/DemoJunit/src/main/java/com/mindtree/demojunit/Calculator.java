package com.mindtree.demojunit;

public class Calculator {
	
	CalculatorService service;
/*	public int add(int i,int j)
	{
		return i+j+1;
		return service.add(i, j);
	}*/
	
	public Calculator(CalculatorService service) {
		// TODO Auto-generated constructor stub
		this.service=service;
	}
	public int perform(int i,int j)//2 3->i+j*2
	{
		/*return i+j+1;*/
		return service.add(i, j);
	}

	
}
