package com.mindtree.junitAndMockito.service.serviceImpl;

import java.util.List;

import com.mindtree.junitAndMockito.dao.employeeDao;
import com.mindtree.junitAndMockito.dao.employeeDaoImpl.EmployeeDaoImpl;
import com.mindtree.junitAndMockito.entity.Employee;
import com.mindtree.junitAndMockito.service.EmployeeService;

public class EmployeeServiceimpl implements EmployeeService{
	
	//employeeDao edao=new EmployeeDaoImpl();
	
	employeeDao edao=new EmployeeDaoImpl();
	public EmployeeServiceimpl(employeeDao edao) {
		// TODO Auto-generated constructor stub
		this.edao=edao;
	}

	/*public EmployeeServiceimpl() {
		// TODO Auto-generated constructor stub
	}*/

	@Override
	public List<Employee> allDetails() {
		// TODO Auto-generated method stub
		return edao.allDetails();
	}

}
