package com.mindtree.junitAndMockito.dao;

import java.util.List;

import com.mindtree.junitAndMockito.entity.Employee;

public interface employeeDao {
	
	
	
	public List<Employee> allDetails();
	
		
	
	

}
