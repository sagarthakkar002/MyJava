package com.mindtree.junitAndMockito.dao.employeeDaoImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.mindtree.junitAndMockito.DbUtil.Util;
import com.mindtree.junitAndMockito.dao.employeeDao;
import com.mindtree.junitAndMockito.entity.Employee;

public class EmployeeDaoImpl implements  employeeDao{
	
	
	public List<Employee> allDetails()
	{
		System.out.println("Employees : xxxx");
		SessionFactory sessionfactory=Util.getConnection();
		Session session = sessionfactory.openSession();
		//session.beginTransaction();
		System.out.println("Employees : hhiiih");
		Query qo=session.createQuery("from Employee");
		List<Employee> emp=qo.list();
		//session.getTransaction().commit();
	    System.out.println("Employees : ");
		emp.forEach(System.out::println);
		return emp;
		
	}

}
