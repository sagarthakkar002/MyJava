package com.mindtree.junitAndMockito.DbUtil;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.junitAndMockito.entity.Employee;

public class Util {
	
	
	public static SessionFactory getConnection()
	{
		
		SessionFactory sessionfactory=new Configuration().configure().addAnnotatedClass(Employee.class).buildSessionFactory();
		return sessionfactory;
		
		
	}

}
