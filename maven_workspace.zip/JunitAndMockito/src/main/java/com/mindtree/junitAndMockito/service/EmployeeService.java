package com.mindtree.junitAndMockito.service;

import java.util.List;

import com.mindtree.junitAndMockito.entity.Employee;

public interface EmployeeService {
	
	public List<Employee> allDetails();

}
