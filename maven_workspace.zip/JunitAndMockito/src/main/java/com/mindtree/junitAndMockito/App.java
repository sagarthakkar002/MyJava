package com.mindtree.junitAndMockito;

import java.util.List;

import com.mindtree.junitAndMockito.entity.Employee;
import com.mindtree.junitAndMockito.service.EmployeeService;
import com.mindtree.junitAndMockito.service.serviceImpl.EmployeeServiceimpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		System.out.println("Hello World!");
/*
		EmployeeService emp = new EmployeeServiceimpl();

		List<Employee> lemp = emp.allDetails();
		System.out.println(lemp);*/
	}
}
