package com.mindtree.junitAndMockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import com.mindtree.junitAndMockito.dao.employeeDao;
import com.mindtree.junitAndMockito.dao.employeeDaoImpl.EmployeeDaoImpl;
import com.mindtree.junitAndMockito.entity.Employee;
import com.mindtree.junitAndMockito.service.EmployeeService;
import com.mindtree.junitAndMockito.service.serviceImpl.EmployeeServiceimpl;

import junit.framework.TestCase;

public class TestJunitAndMockito extends TestCase {
	List<Employee> el= new ArrayList<Employee>();
	@Mock
	/*EmployeeDaoImpl edao;*/
	EmployeeDaoImpl edao=org.mockito.Mockito.mock(EmployeeDaoImpl.class);
	EmployeeService es = null;

	@Before
	public void setUp() {
		es = new EmployeeServiceimpl(edao);

		Employee e = new Employee();
		e.setEmpid(12);
		e.setName("roma");
		e.setSalary(12000);
		el.add(e);

	}

	@Test
	public void testPerform() {
		// when(service.add(2,3)).thenReturn(5);
	//	System.out.println(el);
		//edao=new EmployeeDaoImpl();
		
	//	edao.allDetails();
		//System.out.println(el);
		//System.out.println(edao.allDetails());
		when(edao.allDetails()).thenReturn(el);
		assertEquals(el, es.allDetails());
		verify(edao).allDetails();
		// verify(service).add(2,3);//this only works for mockito but not for stub
	}

}
