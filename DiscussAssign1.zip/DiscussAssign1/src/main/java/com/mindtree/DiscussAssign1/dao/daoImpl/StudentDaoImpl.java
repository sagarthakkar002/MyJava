package com.mindtree.DiscussAssign1.dao.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.DiscussAssign1.dao.StudentDao;
import com.mindtree.DiscussAssign1.entity.Student;
import com.mindtree.DiscussAssign1.exception.daoException.DaoException;
import com.mindtree.DiscussAssign1.exception.util.DbException;
import com.mindtree.DiscussAssign1.util.DbUtil;

public class StudentDaoImpl implements StudentDao{

	public String addStudent(Student s) throws DaoException  {
		
	
			Connection conn;
			try {
				conn = DbUtil.getConnection();
				String query="insert into student values (?,?,?)";
				PreparedStatement stmt=conn.prepareStatement(query);
				stmt.setInt(1, s.getRollNo());
				stmt.setString(2, s.getName());
				stmt.setInt(3, s.getAge());
				stmt.executeUpdate();
			} catch (DbException e) {
				throw new DaoException("add problem",e);
			} catch (SQLException e) {
				throw new DaoException("add ptoblem sql",e);
			}
			
		
		
		
		return "inserted";
	}

	public Student getStudentByRollNo(int rollNo) throws DaoException {
		Connection conn;
		try {
			conn = DbUtil.getConnection();
		} catch (DbException e1) {
			throw new DaoException("Dao me hun"+e1);
		}
		Student s = null;
		String query="select * from student where rollNo=?";
		try {
			PreparedStatement stmt=conn.prepareStatement(query);
			stmt.setInt(1, rollNo);
			ResultSet rs=stmt.executeQuery();
		    
			while(rs.next()) {
				s=new Student();
				s.setRollNo(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setAge(rs.getInt(3));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return s;
	}

	public List<Student> getAllStudent() throws DaoException {
		Connection conn;
		try {
			conn = DbUtil.getConnection();
		} catch (DbException e1) {
			throw new DaoException("Dao me hun"+e1);
		}
		Student s = null;
		List<Student> stulist=new ArrayList<Student>();
		String query="select * from student ";
		try {
			PreparedStatement stmt=conn.prepareStatement(query);
			ResultSet rs=stmt.executeQuery();
			
		    
			while(rs.next()) {
				s=new Student();
				s.setRollNo(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setAge(rs.getInt(3));
				stulist.add(s);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return stulist;
	}

}
