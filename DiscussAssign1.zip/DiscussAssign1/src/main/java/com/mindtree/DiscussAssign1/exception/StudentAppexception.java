package com.mindtree.DiscussAssign1.exception;

public class StudentAppexception extends Exception{

	public StudentAppexception() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentAppexception(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public StudentAppexception(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public StudentAppexception(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public StudentAppexception(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
