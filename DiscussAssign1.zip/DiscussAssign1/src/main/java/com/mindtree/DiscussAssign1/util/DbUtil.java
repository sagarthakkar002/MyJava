package com.mindtree.DiscussAssign1.util;

import java.rmi.StubNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mindtree.DiscussAssign1.exception.StudentAppexception;
import com.mindtree.DiscussAssign1.exception.util.DbException;

public class DbUtil {
	
	private static Connection conn;
	
	public static Connection getConnection() throws DbException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/discussassign1", "root", "Welcome123");
		} catch (ClassNotFoundException e) {
			throw new DbException("could not connect",e);
			
		} catch (SQLException e) {
			throw new DbException("could not connect",e);
			
		}
		return conn;
		
	}
	public static void closeConnection() {
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
