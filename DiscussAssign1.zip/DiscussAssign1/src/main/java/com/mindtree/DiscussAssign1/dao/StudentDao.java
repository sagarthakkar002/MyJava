package com.mindtree.DiscussAssign1.dao;

import java.util.List;

import com.mindtree.DiscussAssign1.entity.Student;
import com.mindtree.DiscussAssign1.exception.daoException.DaoException;

public interface StudentDao {
	
	public String addStudent(Student s) throws DaoException;
	public Student getStudentByRollNo(int rollNo) throws DaoException;
	public List<Student> getAllStudent() throws DaoException;

}
