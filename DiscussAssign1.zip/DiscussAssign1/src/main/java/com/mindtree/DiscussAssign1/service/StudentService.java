package com.mindtree.DiscussAssign1.service;

import java.util.List;

import com.mindtree.DiscussAssign1.entity.Student;
import com.mindtree.DiscussAssign1.exception.serviceException.ServiceException;

public interface StudentService {
	public String addStudent(Student s) throws ServiceException;
	public Student getStudentByRollNo(int rollNo) throws ServiceException;
	public List<Student> getAllStudent() throws ServiceException;
}
