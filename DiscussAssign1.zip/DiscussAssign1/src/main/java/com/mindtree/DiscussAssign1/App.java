package com.mindtree.DiscussAssign1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mindtree.DiscussAssign1.entity.Student;
import com.mindtree.DiscussAssign1.exception.serviceException.ServiceException;
import com.mindtree.DiscussAssign1.service.StudentService;
import com.mindtree.DiscussAssign1.service.serviceImpl.StudentServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException
    
    {
          StudentService s=new  StudentServiceImpl();
          
          
          do {
        	  System.out.println("Enter from below Choice");
        	  System.out.println("1. addStudent 2.getStudent 3.getAll 4.EnterByFile 5.exit");
        	  Scanner sc=new Scanner(System.in);
        	  int choice=sc.nextInt();
        
        	  switch(choice) {
        	  case 1:
        		  Student stu=new Student();
        		  System.out.println("enter the rollNo");
        		  stu.setRollNo(sc.nextInt());
        		  sc.nextLine();
        		  System.out.println("enter the Name");
        		  stu.setName(sc.nextLine());
        		  System.out.println("enter the Age");
        		  stu.setAge(sc.nextInt());
        		  String msg = null;
				try {
					msg = s.addStudent(stu);
				} catch (ServiceException e3) {
					System.out.println(e3.getMessage());
				}
        		  System.out.println("msg:- "+msg);
        		  
        		  break;
        	  case 2:
        		  System.out.println("enter the rollNo");
        		  int rollNo=sc.nextInt();
        		  Student student = null;
				try {
					student = s.getStudentByRollNo(rollNo);
				} catch (ServiceException e2) {
					System.out.println(e2.getMessage());
				}
        		  System.out.println(student.getRollNo()+"\t"+student.getName()+"\t"+student.getAge());
        		  break;
        	  case 3:
        		  List<Student> stulist = null;
				try {
					stulist = s.getAllStudent();
				} catch (ServiceException e1) {
					
				    System.out.println(e1.getMessage());
				}
        		  stulist.forEach(System.out::println);
        		  break;
        	  case 4:
        		  String file=args[0];
        		  List<Student> stlist=new ArrayList<>();
            	  
            	  try(BufferedReader br=new BufferedReader(new FileReader(file))) {
            		  Student stuobj=new Student();
    				String line="";
    				while((line=br.readLine())!=null) {
    					String str[]=line.split(",");
    					stuobj.setRollNo(Integer.parseInt(str[0]));
    					stuobj.setName(str[1]);
    					stuobj.setAge(Integer.parseInt(str[2]));
    					try {
							s.addStudent(stuobj);
						} catch (ServiceException e) {
							
							System.out.println(e.getMessage());
						}
    					stlist.add(stuobj);
    					
    				}
    			} catch (FileNotFoundException e) {
    				e.printStackTrace();
    			}
            	  break;
        	  case 5:
        		  System.exit(0);
        		  break;
        		  
        	  }
        	  
          }while(true);
          
    }
}
