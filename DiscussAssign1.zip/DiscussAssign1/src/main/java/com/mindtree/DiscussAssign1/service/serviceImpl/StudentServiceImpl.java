package com.mindtree.DiscussAssign1.service.serviceImpl;

import java.util.List;

import com.mindtree.DiscussAssign1.dao.StudentDao;
import com.mindtree.DiscussAssign1.dao.daoImpl.StudentDaoImpl;
import com.mindtree.DiscussAssign1.entity.Student;
import com.mindtree.DiscussAssign1.exception.daoException.DaoException;
import com.mindtree.DiscussAssign1.exception.serviceException.ServiceException;
import com.mindtree.DiscussAssign1.service.StudentService;

public class StudentServiceImpl implements StudentService{
	StudentDao sdao=new StudentDaoImpl();

	public String addStudent(Student s) throws ServiceException {
		
		try {
			return sdao.addStudent(s);
		} catch (DaoException e) {
			throw new ServiceException("in add problem",e);
		}
	}

	public Student getStudentByRollNo(int rollNo) throws ServiceException {
		try {
			return sdao.getStudentByRollNo(rollNo);
		} catch (DaoException e) {
			throw new ServiceException("in get Student",e);
		}
	}

	public List<Student> getAllStudent() throws ServiceException {
		
		try {
			return sdao.getAllStudent();
		} catch (DaoException e) {
			throw new ServiceException("In service",e);
		}
	}

}
